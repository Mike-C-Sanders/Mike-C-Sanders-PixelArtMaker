// Select color input
const canvasColor = document.getElementById('colorPicker');

// Select size input
const canvas = document.getElementById('pixelCanvas');
const sizePicker = document.getElementById('sizePicker');
const heightSize = document.getElementById('inputHeight');
const widthSize = document.getElementById('inputWidth');

// When size is submitted by the user, call makeGrid()
sizePicker.addEventListener('submit', function(event){
    event.preventDefault();
    
    //calling the makeGrid Function
    makeGrid(heightSize.value, widthSize.value);

});
function makeGrid(height, width) {
//Reset the grid when pressing submit
    canvas.innerHTML = '';

// Create the rows and columns
    for(let x = 0 ; x < height; x++){
        const row = canvas.insertRow(x);
        //Create each individual cell
        for(let y = 0; y < width; y++){
            const cell = row.insertCell(y);

            //Listening for the click for which cell to change color
            cell.addEventListener('click', function(event){
                //The target event is an individual cell. The goal is to change color.
                const addColor = event.target;
                //Change the cell color
                addColor.style.backgroundColor = canvasColor.value;
            });
        }
    }
}
